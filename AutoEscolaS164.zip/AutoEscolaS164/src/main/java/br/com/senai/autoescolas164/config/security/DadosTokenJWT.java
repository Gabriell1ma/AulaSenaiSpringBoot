package br.com.senai.autoescolas164.config.security;

public record DadosTokenJWT(String tokenJWT) {
}