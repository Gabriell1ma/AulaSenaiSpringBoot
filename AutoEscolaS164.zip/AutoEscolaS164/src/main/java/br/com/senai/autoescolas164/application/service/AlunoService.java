package br.com.senai.autoescolas164.application.service;

import br.com.senai.autoescolas164.application.core.domain.Aluno;
import br.com.senai.autoescolas164.adapter.out.repository.AlunoRepository;
import br.com.senai.autoescolas164.adapter.in.request.aluno.DadosAtualizacaoAluno;
import br.com.senai.autoescolas164.adapter.in.request.aluno.DadosCadastroAluno;
import br.com.senai.autoescolas164.adapter.in.response.aluno.DadosDetalhamentoAluno;
import br.com.senai.autoescolas164.adapter.in.response.aluno.DadosListagemAluno;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AlunoService {

    private final AlunoRepository repository;

    @Transactional
    public DadosDetalhamentoAluno cadastrarAluno(DadosCadastroAluno dados) {
        var aluno = new Aluno(dados);
        Aluno salvo = repository.save(aluno);

        return new DadosDetalhamentoAluno(salvo);
    }

    @Transactional(readOnly = true)
    public @Nullable Page<DadosListagemAluno> listarAlunos(
            Pageable paginacao) {

        return repository
                .findAllByAtivoTrue(paginacao)
                .map(DadosListagemAluno::new);
    }

    @Transactional(readOnly = true)
    public @Nullable DadosDetalhamentoAluno detalharAluno(Long id) {
        Aluno aluno = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "ID do aluno informado não existe!"
                        )
                );

        return new DadosDetalhamentoAluno(aluno);
    }

    @Transactional
    public @Nullable DadosDetalhamentoAluno atualizarAluno(
            DadosAtualizacaoAluno dados) {

        Aluno aluno = repository.findById(dados.id())
                .orElseThrow(() ->
                        new RuntimeException(
                                "ID do aluno informado não existe!"
                        )
                );

        aluno.atualizar(dados);

        Aluno salvo = repository.save(aluno);

        return new DadosDetalhamentoAluno(salvo);
    }

    @Transactional
    public void excluirAluno(Long id) {
        Aluno aluno = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "ID do aluno informado não existe!"
                        )
                );

        aluno.excluir();
        repository.save(aluno);
    }
}
