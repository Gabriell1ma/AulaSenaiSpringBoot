package br.com.senai.autoescolas164.adapter.in.mapper;

import br.com.senai.autoescolas164.adapter.in.request.instrutor.DadosCadastroInstrutor;
import br.com.senai.autoescolas164.application.core.domain.Instrutor;
import br.com.senai.autoescolas164.shared.Endereco;
import org.springframework.stereotype.Component;

@Component
public class InstrutorMapper {
    public Instrutor toDomaind(DadosCadastroInstrutor dados){
        return new Instrutor(
                null,
                dados.nome(),
                dados.email(),
                dados.telefone(),
                dados.cnh(),
                true,
                dados.especialidade(),
                new Endereco(dados.endereco())
        );
    }

}
