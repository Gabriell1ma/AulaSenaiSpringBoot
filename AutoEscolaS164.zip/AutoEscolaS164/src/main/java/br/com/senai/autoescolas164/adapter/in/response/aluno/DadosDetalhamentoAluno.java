package br.com.senai.autoescolas164.adapter.in.response.aluno;

import br.com.senai.autoescolas164.application.core.domain.Aluno;
import br.com.senai.autoescolas164.shared.Endereco;

public record DadosDetalhamentoAluno (
        Long id,
        String nome,
        String email,
        String telefone,
        String cpf,
        Endereco endereco,
        boolean ativo) {
    public DadosDetalhamentoAluno(Aluno aluno) {
        this(
                aluno.getId(),
                aluno.getNome(),
                aluno.getEmail(),
                aluno.getTelefone(),
                aluno.getCpf(),
                aluno.getEndereco(),
                aluno.isAtivo()
        );
    }
}

