package br.com.senai.autoescolas164.shared.mapper;

public class EnderecoMapper {
}
