package br.com.senai.autoescolas164.application.core.domain;

import br.com.senai.autoescolas164.shared.Endereco;
import br.com.senai.autoescolas164.adapter.in.request.instrutor.DadosAtualizacaoInstrutor;
import br.com.senai.autoescolas164.shared.vo.enumeration.Especialidade;


public class Instrutor {

    private Long id;
    private String nome;
    private String email;
    private String telefone;
    private String cnh;
    private boolean ativo = true;
    private Especialidade especialidade;
    private Endereco endereco;

    public Instrutor() {
    }

    public Instrutor(Long id, String nome, String email, String telefone, String cnh, boolean ativo, Especialidade especialidade, Endereco endereco) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
        this.cnh = cnh;
        this.ativo = ativo;
        this.especialidade = especialidade;
        this.endereco = endereco;
    }

    public Long getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getCnh() {
        return cnh;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public Especialidade getEspecialidade() {
        return especialidade;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void atualizar(DadosAtualizacaoInstrutor dados) {
        if (dados.nome() != null && !dados.nome().isBlank()) {
            this.nome = dados.nome();
        }
        if (dados.email() != null && !dados.email().isBlank()) {
            this.email = dados.email();
        }
        if (dados.telefone() != null && !dados.telefone().isBlank()) {
            this.telefone = dados.telefone();
        }
        if (dados.especialidade() != null) {
            this.especialidade = dados.especialidade();
        }
        if (dados.endereco() != null) {
            this.endereco.atualizar(dados.endereco());
        }
    }

    public void excluir() {
        this.ativo = false;
    }
}