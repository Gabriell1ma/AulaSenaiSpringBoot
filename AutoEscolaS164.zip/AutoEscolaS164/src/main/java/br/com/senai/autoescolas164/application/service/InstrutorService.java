package br.com.senai.autoescolas164.application.service;

import br.com.senai.autoescolas164.adapter.in.mapper.InstrutorMapper;
import br.com.senai.autoescolas164.adapter.in.request.instrutor.DadosAtualizacaoInstrutor;
import br.com.senai.autoescolas164.adapter.in.request.instrutor.DadosCadastroInstrutor;
import br.com.senai.autoescolas164.adapter.in.response.instrutor.DadosDetalhamentoInstrutor;
import br.com.senai.autoescolas164.adapter.in.response.instrutor.DadosListagemInstrutor;
import br.com.senai.autoescolas164.adapter.out.repository.InstrutorRepository;
import br.com.senai.autoescolas164.application.core.domain.Instrutor;
import lombok.RequiredArgsConstructor;
import org.jspecify.annotations.Nullable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class InstrutorService {
    private final InstrutorRepository repository;
    private final InstrutorMapper mapper;

    @Transactional
    public DadosDetalhamentoInstrutor cadastrarInstrutor(DadosCadastroInstrutor dados) {
        Instrutor instrutor = mapper.toDomaind(dados);
        Instrutor salvo = repository.save(instrutor);
        return new DadosDetalhamentoInstrutor(salvo);
    }

    @Transactional(readOnly = true)
    public @Nullable Page<DadosListagemInstrutor> listarInstrutores(Pageable paginacao) {
        return repository
                .findAllByAtivoTrue(paginacao)
                .map(DadosListagemInstrutor::new);
    }

    @Transactional(readOnly = true)
    public @Nullable DadosDetalhamentoInstrutor detalharInstrutor(Long id) {
        Instrutor instrutor = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("ID do instrutor informado não existe!"));
        return new DadosDetalhamentoInstrutor(instrutor);
    }

    @Transactional
    public @Nullable DadosDetalhamentoInstrutor atualizarInstrutor(DadosAtualizacaoInstrutor dados) {
        Instrutor instrutor = repository.findById(dados.id())
                .orElseThrow(() -> new RuntimeException("ID do instrutor informado não existe!"));
        instrutor.atualizar(dados);
        Instrutor salvo = repository.save(instrutor);
        return new DadosDetalhamentoInstrutor(salvo);
    }

    @Transactional
    public void excluirInstrutor(Long id) {
        Instrutor instrutor = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("ID do instrutor informado não existe!"));
        instrutor.excluir();
        repository.save(instrutor);
    }
}