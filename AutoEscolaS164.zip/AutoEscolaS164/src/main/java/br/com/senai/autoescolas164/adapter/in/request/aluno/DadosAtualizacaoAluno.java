package br.com.senai.autoescolas164.adapter.in.request.aluno;

import br.com.senai.autoescolas164.shared.DadosEndereco;


public record DadosAtualizacaoAluno (
    Long id,
    String nome,
    String email,
    String telefone,
    String cpf,
    DadosEndereco endereco) {
    }
