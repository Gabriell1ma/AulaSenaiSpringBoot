package br.com.senai.autoescolas164.application.core.specification.agendamento;

import br.com.senai.autoescolas164.adapter.in.request.instrucao.DadosAgendamento;

public interface ValidadorAgendamento {
    void validar(DadosAgendamento dados);
}